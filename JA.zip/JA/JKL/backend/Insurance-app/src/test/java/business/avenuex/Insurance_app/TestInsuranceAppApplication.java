package business.avenuex.Insurance_app;

import org.springframework.boot.SpringApplication;

public class TestInsuranceAppApplication {

	public static void main(String[] args) {
		SpringApplication.from(InsuranceAppApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
